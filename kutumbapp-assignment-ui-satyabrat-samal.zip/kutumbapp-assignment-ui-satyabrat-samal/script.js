
// Login functionality
function userLogin(){
    if (location.pathname.includes("index.html")) {
        document.getElementById("login-form").addEventListener("submit", async (e) => {
            e.preventDefault();
            const username = document.getElementById("username").value;
            const otp = document.getElementById("otp").value;
    
            const response = await fetch(`https://assignment.stage.crafto.app/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, otp })
            });
    
            const data = await response.json();
            if (data.token) {
                sessionStorage.setItem("token", data.token);
                location.href = "quotes.html";
            } else {
                alert("Login failed!");
            }
        });
    }
}


//  quotes and  pagination
if (location.pathname.includes("quotes.html")) {
    document.getElementById("loader").classList.add("active-loader");
    let offset = 0;
    const limit = 20;

    async function loadQuotes() {
        const token = sessionStorage.getItem("token");
        const response = await fetch(`https://assignment.stage.crafto.app/getQuotes?limit=${limit}&offset=${offset}`, {
            headers: { Authorization: token }
        });

        const quotes = await response.json();
        if (quotes.length === 0) {
            document.getElementById("load-more").style.display = "none";
            return;
        }

        const quoteList = document.getElementById("quote-list");
        const quoteData = quotes.data
        quoteData.forEach(quote => {
            if (quote.mediaUrl != null && quote.mediaUrl != '') {
                const div = document.createElement("div");
                div.className = "quote";
                div.innerHTML = `
                    <img src="${quote.mediaUrl}" alt="Quote Image">
                    <div class="quote-overlay">
                        <p>${quote.text.toLocaleUpperCase()}</p>
                        <p><small>${quote.username} - ${new Date(quote.createdAt).toLocaleString()}</small></p>
                    </div>
                `;
                quoteList.appendChild(div);
            }
        });

        offset += limit;
        setTimeout(() => {
            document.getElementById("loader").classList.remove("active-loader");
        }, 2000);
    }

    document.getElementById("load-more").addEventListener("click", loadQuotes);
    document.getElementById("create-quote").addEventListener("click", () => {
        location.href = "create-quote.html";
    });

    loadQuotes();
}

//quote create
if (location.pathname.includes("create-quote.html")) {
    document.getElementById("quote-form").addEventListener("submit", async (e) => {
        e.preventDefault();

        const text = document.getElementById("quote-text").value;
        const file = document.getElementById("quote-image").files[0];
        const token = sessionStorage.getItem("token");

        if (!file) {
            alert("Please select a file.");
            return;
        }
        const formData = new FormData();
        formData.append("file", file);

        // Step 1:
        const uploadResponse = await fetch('https://crafto.app/crafto/v1.0/media/assignment/upload', {
            method: "POST",
            body: formData,
        });

        const uploadData = await uploadResponse.json();

        console.log(uploadData);

        if (!uploadData || !uploadData[0] || !uploadData[0].url) {
            console.error("Image upload failed:", uploadData);
            alert("Image upload failed!");
            return;
        }

        // Step 2:
        const response = await fetch('https://assignment.stage.crafto.app/postQuote', {
            method: "POST",
            headers: {
                Authorization: token,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                text: text,
                mediaUrl: uploadData[0].url 
            })
        });

        if (response.ok) {
            alert("Quote created successfully!");
            location.href = "quotes.html";
        } else {
            alert("Failed to create quote.");
        }
    });
}




